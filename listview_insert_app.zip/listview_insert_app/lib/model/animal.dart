class Animal{
  // Field
  String imagePath;
  String animalName;
  String kind;
  bool flyExist;

  // Constructor
  Animal(
    {
      required this.imagePath,
      required this.animalName,
      required this.kind,
      required this.flyExist
    }
  );

  // Function

}