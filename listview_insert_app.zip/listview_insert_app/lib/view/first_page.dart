import 'package:flutter/material.dart';
import 'package:listview_insert_app/model/animal.dart';

class FirstPage extends StatefulWidget {
  final List<Animal> list;
  const FirstPage({super.key, required this.list});

  @override
  State<FirstPage> createState() => _FirstPageState();
}

class _FirstPageState extends State<FirstPage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}