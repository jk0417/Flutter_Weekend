import 'package:flutter/material.dart';
import 'package:listview_insert_app/model/animal.dart';

class SecondPage extends StatefulWidget {
  final List<Animal> list;  
  const SecondPage({super.key, required this.list});

  @override
  State<SecondPage> createState() => _SecondPageState();
}

class _SecondPageState extends State<SecondPage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}