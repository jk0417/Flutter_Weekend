import 'package:flutter/material.dart';
import 'package:listview_insert_app/model/animal.dart';

class SecondPage extends StatefulWidget {
  final List<Animal> list;  
  const SecondPage({super.key, required this.list});

  @override
  State<SecondPage> createState() => _SecondPageState();
}

class _SecondPageState extends State<SecondPage> {
  // Field
  late TextEditingController nameController;
  late int _radioValue; // Radio Group
  late bool flyExist;   // Check Box
  late String _imagePath; // 이미지 경로
  late String imageName;  // 이미지 이름

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    nameController = TextEditingController();
    _radioValue = 0; 
    flyExist = false;
    _imagePath = "";
    imageName = "없습니다.";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          TextField(
            controller: nameController,
            keyboardType: TextInputType.text,
            maxLines: 1,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Radio(
                value: 0, 
                groupValue: _radioValue, 
                onChanged: (value) {
                  setState(() {
                    _radioValue = value!;
                  });
                },
              ),
              const Text('양서류'),
              Radio(
                value: 1, 
                groupValue: _radioValue, 
                onChanged: (value) {
                  setState(() {
                    _radioValue = value!;
                  });
                },
              ),
              const Text('파충류'),
              Radio(
                value: 2, 
                groupValue: _radioValue, 
                onChanged: (value) {
                  setState(() {
                    _radioValue = value!;
                  });
                },
              ),
              const Text('포유류'),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('날 수 있나요?'),
              Checkbox(
                value: flyExist, 
                onChanged: (value) {
                  setState(() {
                    flyExist = value!;
                  });
                },
              ),
            ],
          ),
          SizedBox(
            height: 100,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                GestureDetector(
                  onTap: () {
                    _imagePath = "images/cow.png";
                    setState(() {
                      imageName = "젖소";
                    }); 
                  },
                  child: Image.asset(
                    'images/cow.png'
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    _imagePath = "images/pig.png";
                    setState(() {
                      imageName = "돼지";
                    }); 
                  },
                  child: Image.asset(
                    'images/pig.png'
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    _imagePath = "images/bee.png";
                    setState(() {
                      imageName = "벌";
                    }); 
                  },
                  child: Image.asset(
                    'images/bee.png'
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    _imagePath = "images/cat.png";
                    setState(() {
                      imageName = "고양이";
                    }); 
                  },
                  child: Image.asset(
                    'images/cat.png'
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    _imagePath = "images/fox.png";
                    setState(() {
                      imageName = "여우";
                    }); 
                  },
                  child: Image.asset(
                    'images/fox.png'
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    _imagePath = "images/monkey.png";
                    setState(() {
                      imageName = "원숭이";
                    }); 
                  },
                  child: Image.asset(
                    'images/monkey.png'
                  ),
                ),
              ],
            ),
          ),
          Text(
            "선택된 이미지는 $imageName"
          ),
          ElevatedButton(
            onPressed: () {
              insertAction(context);
            }, 
            child: const Text('동물 추가하기'),
          ),
        ],
      ),
    );
  }

  // --- Functions ---
  insertAction(BuildContext context){
    showDialog(
      barrierDismissible: false,
      context: context, 
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text(
            '동물 추가하기'
          ),
          content: Text(
            '이 동물은 ${nameController.text} 입니다.'
            '또 동물의 종류는 ${getKind(_radioValue)} 입니다. \n'
            '이 동물은 ${flyExist ? "날 수 있습니다" : "날 수 없습니다"} \n'
            '이 동물을 추가 하시겠습니까?'
          ),
          actions: [
            TextButton(
              onPressed: () {
                var animal = Animal(
                  imagePath: _imagePath, 
                  animalName: nameController.text, 
                  kind: getKind(_radioValue), 
                  flyExist: flyExist);

                widget.list.add(animal); 
                Navigator.of(context).pop();
              }, 
              child: const Text('예'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              }, 
              child: const Text('아니오'),
            ),
          ],
        );
      },
      );
  }  

  getKind(int radioValue){
    switch(radioValue){
      case 0:
        return '양서류';
      case 1:
        return '파충류';
      case 2:
        return '포유류';
    }
  }


} // End