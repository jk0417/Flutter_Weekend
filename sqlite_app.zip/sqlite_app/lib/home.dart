import 'package:flutter/material.dart';
import 'package:sqlite_app/database_handler.dart';
import 'package:sqlite_app/students.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  late DatabaseHandler handler;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    handler = DatabaseHandler();
    handler.initializeDB().whenComplete(() async{
      await addStudents(); // Test용 Insert
      setState(() {
        
      });
    });
  }

  // Test용 Insert Action
  Future<int> addStudents() async{
    Students firstStudent = Students(code: '1111', name: '유비', dept: '컴퓨터공학과', phone: '1111');
    await handler.insertStudents(firstStudent);
    Students secondStudent = Students(code: '2222', name: '관우', dept: '심리학과', phone: '2222');
    await handler.insertStudents(secondStudent);
    Students thirdStudent = Students(code: '3333', name: '장비', dept: '시각디자인학과', phone: '3333');
    await handler.insertStudents(thirdStudent);
    
    return 0;
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SQLite for Students'),
      ),
      body: FutureBuilder(
        future: handler.queryStudents(),
        builder: (BuildContext context, AsyncSnapshot<List<Students>> snapshot){
          if(snapshot.hasData){
            return ListView.builder(
              itemCount: snapshot.data?.length,
              itemBuilder: (BuildContext context, int index) {
                return Card(
                  child: Column(
                    children: [
                      Row(
                        children: [
                          const Text(
                            "Code :",
                            style: TextStyle(
                              fontWeight: FontWeight.bold
                            ),
                          ),
                          Text(
                            snapshot.data![index].code
                          )
                        ],
                      )
                    ],
                  ),
                );
              }
            );
          }else{
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }






} // End